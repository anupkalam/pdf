"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity, Users, Calendar, TrendingUp } from "lucide-react"
import { getDashboardStats, getWeeklyPatientData } from "@/lib/data"
import { Bar, BarChart, XAxis, YAxis, CartesianGrid } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const chartConfig = {
  patients: {
    label: "Patients",
    color: "hsl(var(--chart-1))",
  },
}

export default function Dashboard() {
  const stats = getDashboardStats()
  const weeklyData = getWeeklyPatientData()

  const statCards = [
    {
      title: "Total Patients",
      value: stats.totalPatients,
      description: "Active patient records",
      icon: Users,
      color: "text-blue-600",
    },
    {
      title: "Daily Patients",
      value: stats.dailyPatients,
      description: "Patients seen today",
      icon: Activity,
      color: "text-green-600",
    },
    {
      title: "Weekly Patients",
      value: stats.weeklyPatients,
      description: "Patients this week",
      icon: Calendar,
      color: "text-orange-600",
    },
    {
      title: "Monthly Patients",
      value: stats.monthlyPatients,
      description: "Patients this month",
      icon: TrendingUp,
      color: "text-purple-600",
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">Welcome to SIGMA Clinic management system</p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((card, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{card.value}</div>
              <p className="text-xs text-muted-foreground">{card.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Weekly Patient Visits</CardTitle>
            <CardDescription>Patient visits over the past week</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <ChartContainer config={chartConfig} className="h-[300px]">
              <BarChart data={weeklyData}>
                <CartesianGrid vertical={false} />
                <XAxis dataKey="day" tickLine={false} tickMargin={10} axisLine={false} />
                <YAxis tickLine={false} axisLine={false} tickMargin={8} />
                <ChartTooltip cursor={false} content={<ChartTooltipContent hideLabel />} />
                <Bar dataKey="patients" fill="var(--color-patients)" radius={8} />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Quick Stats</CardTitle>
            <CardDescription>Key metrics at a glance</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Active Patients</span>
              <span className="text-2xl font-bold text-green-600">{stats.activePatients}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Avg. Daily Visits</span>
              <span className="text-2xl font-bold text-blue-600">8.2</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Treatment Success</span>
              <span className="text-2xl font-bold text-purple-600">94%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Patient Satisfaction</span>
              <span className="text-2xl font-bold text-orange-600">4.8/5</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
