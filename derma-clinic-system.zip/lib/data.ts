export interface Patient {
  id: string
  name: string
  age: number
  contact: string
  email: string
  condition: string
  visitDate: string
  status: "Active" | "Inactive"
  gender: "Male" | "Female" | "Other"
}

export interface Appointment {
  id: string
  patientId: string
  patientName: string
  date: string
  time: string
  doctor: string
  type: string
  status: "Scheduled" | "Completed" | "Cancelled"
}

export interface Product {
  id: string
  name: string
  category: string
  price: number
  stock: number
  available: boolean
  description: string
}

// Static patient data
export const patients: Patient[] = [
  {
    id: "1",
    name: "Sarah Johnson",
    age: 28,
    contact: "+1-555-0123",
    email: "sarah.johnson@email.com",
    condition: "Acne Treatment",
    visitDate: "2024-01-15",
    status: "Active",
    gender: "Female",
  },
  {
    id: "2",
    name: "Michael Chen",
    age: 35,
    contact: "+1-555-0124",
    email: "michael.chen@email.com",
    condition: "Eczema",
    visitDate: "2024-01-14",
    status: "Active",
    gender: "Male",
  },
  {
    id: "3",
    name: "Emily Davis",
    age: 42,
    contact: "+1-555-0125",
    email: "emily.davis@email.com",
    condition: "Psoriasis",
    visitDate: "2024-01-13",
    status: "Active",
    gender: "Female",
  },
  {
    id: "4",
    name: "James Wilson",
    age: 31,
    contact: "+1-555-0126",
    email: "james.wilson@email.com",
    condition: "Skin Cancer Screening",
    visitDate: "2024-01-12",
    status: "Inactive",
    gender: "Male",
  },
  {
    id: "5",
    name: "Lisa Anderson",
    age: 26,
    contact: "+1-555-0127",
    email: "lisa.anderson@email.com",
    condition: "Rosacea",
    visitDate: "2024-01-11",
    status: "Active",
    gender: "Female",
  },
]

// Static appointment data
export const appointments: Appointment[] = [
  {
    id: "1",
    patientId: "1",
    patientName: "Sarah Johnson",
    date: "2024-01-20",
    time: "09:00",
    doctor: "Dr. Smith",
    type: "Follow-up",
    status: "Scheduled",
  },
  {
    id: "2",
    patientId: "2",
    patientName: "Michael Chen",
    date: "2024-01-20",
    time: "10:30",
    doctor: "Dr. Brown",
    type: "Consultation",
    status: "Scheduled",
  },
  {
    id: "3",
    patientId: "3",
    patientName: "Emily Davis",
    date: "2024-01-19",
    time: "14:00",
    doctor: "Dr. Smith",
    type: "Treatment",
    status: "Completed",
  },
  {
    id: "4",
    patientId: "4",
    patientName: "James Wilson",
    date: "2024-01-21",
    time: "11:00",
    doctor: "Dr. Johnson",
    type: "Screening",
    status: "Scheduled",
  },
  {
    id: "5",
    patientId: "5",
    patientName: "Lisa Anderson",
    date: "2024-01-18",
    time: "15:30",
    doctor: "Dr. Brown",
    type: "Consultation",
    status: "Completed",
  },
]

// Static product data
export const products: Product[] = [
  {
    id: "1",
    name: "Retinol Serum",
    category: "Anti-Aging",
    price: 89.99,
    stock: 25,
    available: true,
    description: "Advanced retinol serum for fine lines and wrinkles",
  },
  {
    id: "2",
    name: "Vitamin C Brightening Cream",
    category: "Brightening",
    price: 65.5,
    stock: 0,
    available: false,
    description: "Brightening cream with 20% Vitamin C",
  },
  {
    id: "3",
    name: "Hyaluronic Acid Moisturizer",
    category: "Hydration",
    price: 45.0,
    stock: 18,
    available: true,
    description: "Deep hydrating moisturizer with hyaluronic acid",
  },
  {
    id: "4",
    name: "Salicylic Acid Cleanser",
    category: "Acne Treatment",
    price: 32.99,
    stock: 12,
    available: true,
    description: "Gentle cleanser for acne-prone skin",
  },
  {
    id: "5",
    name: "Niacinamide Serum",
    category: "Pore Control",
    price: 28.75,
    stock: 8,
    available: true,
    description: "10% Niacinamide serum for pore refinement",
  },
  {
    id: "6",
    name: "Sunscreen SPF 50",
    category: "Sun Protection",
    price: 38.0,
    stock: 0,
    available: false,
    description: "Broad spectrum sunscreen for daily protection",
  },
]

// Helper functions for dashboard stats
export const getDashboardStats = () => {
  const totalPatients = patients.length
  const activePatients = patients.filter((p) => p.status === "Active").length

  // Mock daily, weekly, monthly counts (in real app, this would be calculated from actual dates)
  const dailyPatients = 3
  const weeklyPatients = 12
  const monthlyPatients = 45

  return {
    totalPatients,
    activePatients,
    dailyPatients,
    weeklyPatients,
    monthlyPatients,
  }
}

// Mock chart data for patient visits over the week
export const getWeeklyPatientData = () => [
  { day: "Mon", patients: 8 },
  { day: "Tue", patients: 12 },
  { day: "Wed", patients: 6 },
  { day: "Thu", patients: 15 },
  { day: "Fri", patients: 10 },
  { day: "Sat", patients: 4 },
  { day: "Sun", patients: 2 },
]
